 <?php 
session_start();
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==1) {
   header("Location:admin.php");
  die();
}
if ($_SESSION['role']==3) {
   header("Location:shop.php");
  die();
}


 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Cart</title>
    <link rel="stylesheet" type="text/css" href="nav.css">
    <link rel="stylesheet" type="text/css" href="footer.css">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
<?php 
include 'custNav.php';
 ?>
     
 </header>
 <section class="control">
   	<h2>
		Your Orders
	</h2>
  <?php  
   $sql = "SELECT * FROM orders WHERE user_id = '$_SESSION[id]'";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) {
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Shop</th>
                       
                        <th>Status</th>
                        <th>Delete</th>
   
                        
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {
                    	 $sql1 = "SELECT * FROM products WHERE product_id = '$row[product_id]' ";
                $result1 = mysqli_query($conn ,$sql1);
                 if ( mysqli_num_rows($result1) > 0) { 
                    $row1 = mysqli_fetch_assoc($result1); 
                     
                 $sql2 = "SELECT * FROM shop WHERE shop_id = '$row1[shop_id]' ";
                $result2 = mysqli_query($conn ,$sql2);
                                 if ( mysqli_num_rows($result2) > 0) { 
                $row2 = mysqli_fetch_assoc($result2); }

                }

           
            	?>
                        
                        <tr>
                            <td><?=$row['order_id']?></td> 
                            <td><?=$row1['product_name']?></td>
                             <td><?=$row2['shop_name']?></td>
                             <td><?php  if ($row['success']==1) {?>
                             	Completed 
                             	<td>-</td><?php } elseif ($row['success']==0) { ?>
                             		Waiting 
                            </td>
                             
                                <form action="delete2.php" method="get"><td><a href="delete2.php?order_id=<?=$row['order_id'] ?>">delete</a> </td></form> <?php } ?> 
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>

  <?php 
include 'footer.php';
 ?>
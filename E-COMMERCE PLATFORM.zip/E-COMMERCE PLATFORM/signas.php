<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
	<meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>

  <h1 class="join">
  	Join Us As:
  </h1>
   <button class="option"> <a href="saleReg.php">
   	Saler
   </a>
</button> <br>
   <button class="option"><a href="buyReg.php">
   	Coustmer
  </a> </button>
  <style>
  	
  	body {
      		background-color:#F2F2F2;
      		text-align: center;
      		font-family: serif; 
      		color: green;
      	}
      	h1 {
      		padding: 6%;
      		font-weight: 600;
      		font-size: 50px;
      	}
      	button {
      		background-color: white;
      		font-size: 35px;
      		font-weight: 500;
      		margin: 20px;
      		border-radius: 10px;
      		padding: 13px;
      		
      	}
      	a {
      		text-decoration: none;
      		color: green;
      	}
  </style>

  <?php 
include 'footer.php';
 ?>

<?php 
session_start();
require 'connect.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Markazy</title>
	<link rel="stylesheet" type="text/css" href="nav.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta content="width=device-width,initial-scale=1" name="viewport">
	<style>
		
		nav {
			position: initial;
		}
	</style>
</head>
<body>
<?php 
if ($_SESSION['role']== '2') {
	include 'custNav.php'; ?>
	<section>
 	<button ><a href="products.php">Products</a>
 		
 	</button>

 </section>
<?php } 


if ($_SESSION['role']== '3') {

	include 'salNav.php';
}
if ($_SESSION['role']== '1') {
	include 'adminNav.php';
}
 ?>
   search........./categories.........
 <?php 

include 'footer.php';
  ?>
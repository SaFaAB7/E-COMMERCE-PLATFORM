<?php 
session_start();
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==1) {
   header("Location:admin.php");
  die();
}
if ($_SESSION['role']==2) {
   header("Location:products.php");
  die();
}


  
  $productName = $productDesc = $productNameErr = $productDescErr = $price =$priceErr='';
  if($_SERVER['REQUEST_METHOD'] == "POST"){
  	if (isset($_POST['send'])) {
  	
    if(isset($_POST["name"])){
        $productName=$_POST["name"];
        if(empty($_POST["name"])){
        $productNameErr = "Product Name is required";
        unset($_POST["name"]);}
} 
if (isset($_POST["desc"])){
        $productDesc=$_POST["desc"];
        } else {
$productDescErr = "product Type is required";
        unset($_POST["desc"]);}
if (isset($_POST["price"])){
        $price=$_POST["price"];
        if(empty($_POST["price"])){
        $price = 0;}
        elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm]/",$_POST["price"])){
    $priceErr = "Please Inter Only Numbers";
        unset($_POST["price"]);}
}
     // if (!empty($_FILES['image'])) {
     //       $imageName = $_FILES['image']['name'];
     //    $tmp = $_FILES['image']['tmp_name'];

     //    $upload = 'images/'.$imageName;
     //    if ($_FILES['image']['error'] == 0) {
     //        if (move_uploaded_file($tmp, $upload)) { 
                if ($productNameErr =='' and $productDescErr == '' and $priceErr =='') {
      $sql = "INSERT INTO products (product_name ,shop_id ,user_id , type , price) VALUES ('$productName' , '$_GET[shop_id]', '$_SESSION[id]' , ' $productDescErr' , '$price')";
        $result = mysqli_query($conn ,$sql); 
   
    
        if (!$result) {
         unset($_POST["send"]);
         unset($_POST["name"]);
          unset($_POST["desc"]);
          unset($_POST["price"]);
  
  // }
 }
}
}
}
    
 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Shop</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="footer.css">
  <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
 
      <section>

  <div class="container">
     
       <section id="addproduct">
        <h2>Add Products</h2>
        <form action="" method="post">
            <label for="name">Product Name</label><br> <span class="error"><?= $productNameErr ?></span>
            <input type="text" name="name" id="name" placeholder="Product Name"><br>

            <label for="image">Product Picture</label><br>
            <input type="file" name="image" id="image" placeholder="Product Image"><br>

              <label for="desc">Product Type</label><br>  <span class="error"><?= $productDescErr ?></span>
            <input  type="text" name="desc" id="desc" placeholder="Product Type"><br>


              <label for="desc">Price</label><br> <p style="font-size: 14px;">Please Leave it empty if you want to recive Requests</p> <span class="error"><?= $priceErr ?></span>
            <input  type="text" name="price" id="price" placeholder="Product Price"><br>


            <button type="submit" id="send" name="send">Add</button>
            
        </form>
  </section>
  
<?php 
include 'footer.php';
 ?>
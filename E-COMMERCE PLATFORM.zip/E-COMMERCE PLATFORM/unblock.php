<?php 
session_start();
require 'connect.php';
if (isset($_GET['user_id'])) {
	
$sql = "UPDATE users SET block = '0' WHERE user_id = '$_GET[user_id]'";
$result = mysqli_query($conn,$sql);
if ($result) {
	header("Location:controladmin.php");
}
}

 ?>
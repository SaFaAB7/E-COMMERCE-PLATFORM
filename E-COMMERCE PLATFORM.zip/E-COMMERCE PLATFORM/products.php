<?php 
session_start();
  require 'connect.php';
  if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==3) {
   header("Location:shop.php");
  die();
}
if ($_SESSION['role']==1) {
   header("Location:admin.php");
  die();
} 
 ?>
<!DOCTYPE html>
<html>
<head>
  <title>Products</title>
  
  <link rel="stylesheet" type="text/css" href="footer.css">
  <link rel="stylesheet" type="text/css" href="nav.css">
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
<header>
  <?php 
   include 'custNav.php';
   ?>
</header>
<main>
   
	<?php
  
      
      // if (isset($_GET['search'])) {
      //  $serch =$_GET['search'];
      //  $sql = "SELECT * FROM products WHERE product_name LIKE '%$serch%'";
      //       $result = mysqli_query($conn ,$sql) ; 
      // }
      //    else {
       			$sql = "SELECT * FROM products ";
       			$result = mysqli_query($conn ,$sql);
            //}

       				if (mysqli_num_rows($result) >0) {
       		 while ($row = mysqli_fetch_assoc($result)) {

                  $sql1 = "SELECT * FROM shop WHERE shop_id = '$row[product_name]' ";
            $result1 = mysqli_query($conn ,$sql1);
              if (mysqli_num_rows($result1) >0){
                $row1 = mysqli_fetch_assoc($result1);
              }
            ?>
           
 <section class="productcontent"> 
       			  <article class="product">
                    
                     <img src="image/background1.jpg" alt="product image" class="img1" width="33%"> 
                    <img src="image/background1.jpg" alt="product image" class="img2" width="33%"> 
                  <div class="content"> 
                       <h3 class="poductname"><a class="a" href="product.php?product_id=<?=$row['product_id']?>"><?=$row['product_name']?></a></h3>
                <h3 class="price">
                        <?=$row['type']?>
                    </h3>
                    <h3 class="price">
                        <?=$row['price']?>
                    </h3>
                    <button class="viewbtn"><a href="cart.php?product_id=<?=$row['product_id']?>">add to cart</a></button>
                      <button class="viewbtn"><a href="contact.php?user_id=<?=$row['user_id']?>">Request Price</a></button>
                </div>
                </article>
              </section>
                 <?php  }}
                 else{?>
                 <span class="noresult">
                   No Results
                 </span>
                <?php  } ?> 

             
</main>

 <?php 
include 'footer.php';
 ?>
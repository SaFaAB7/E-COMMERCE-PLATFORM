<?php
session_start();
require 'connect.php';

$name1 =$name2= $email = $company = $com_role = $psw = $pswrepeat = '';
$nameErr = $emailErr = $pswErr = $repeat_err = $roleErr = $companyErr ='';
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['signup'])){
    if(isset($_POST["firstname"])){
        $tname1=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $nameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $nameErr = "Only letters allowed";
    unset($_POST["firstname"]);}
}else{ 
$nameErr = "First Name is required";
}
if(isset($_POST["lastname"])){
    $name2=$_POST["lastname"];
    if(empty($_POST["lastname"])){
    $nameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$nameErr = "Only letters allowed";
unset($_POST["lastname"]);}
}else{ 
$nameErr = "Last Name is required";
}
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM users WHERE email = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}else{
    $emailErr = "Email is required";
}if(isset($_POST["company"])){
        $company=$_POST["company"];
        if(empty($_POST["company"])){
        $companyErr = "Company Name is required";
        unset($_POST["company"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["company"])){
    $companyErr = "Only letters allowed";
    unset($_POST["company"]);}
}else{ 
$companyErr = "Company Name is required";
}
if(isset($_POST["com_role"])){
        $com_role=$_POST["com_role"];
        if(empty($_POST["com_role"])){
        $roleErr = "Pleas Write Your Role ";
        unset($_POST["com_role"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["com_role"])){
    $roleErr = "Only letters allowed";
    unset($_POST["com_role"]);}
}else{ 
$roleErr = "Role is required";
}if(isset($_POST['password'])){
    $password = $_POST['password'];
    if(empty($_POST['password'])){
        $passwordErr = "Password is Required";
        unset($_POST['password']);
    }elseif(strstr($_POST['password'],"\s")){
        $passwordErr = "Your password should not include whitespace";
        unset($_POST['password']);
    }
    elseif(strlen($_POST['password']) < 8){
        $passwordErr = "Your password should have at least 8 characters";
        unset($_POST['password']);
    }elseif(strlen($_POST['password']) > 16){
        $passwordErr = "Your password should not exceed 16 characters";
        unset($_POST['password']);
    }
}else{
    $passwordErr = "Password is Required";
}if(isset($_POST['reppassword'])){
    $reppassword = $_POST['reppassword'];
    if(empty($_POST['reppassword'])){
        $reppasswordErr = "Repeat your Password";
        unset($_POST['reppassword']);
    }elseif($_POST['reppassword'] !== $password){
        $reppasswordErr = "The passwords dont match";
        unset($_POST['reppassword']);
    }
}else{
    $reppasswordErr = "Repeat your Password";
}
if($nameErr == ''  and  $emailErr == '' and  $pswErr == '' and $repeat_err =='' and $roleErr =='' and $companyErr == ''){


   $insert= "INSERT INTO users (first_name , last_name , email ,company_name , company_role , role , password ) VALUES ('$name1' ,'$name2', '$email' ,'$company','$com_role' ,'2', '$psw')";
   $result1 = mysqli_query($conn, $insert);
   
    header("Location:login.php");  }
    }?>

<!DOCTYPE html>
<html>
    <head>
    <title>SIGN UP</title>
<meta content="width=device-width, initial-scale=1" name="viewport" />
<link rel="stylesheet" type="text/css" href="register.css">
<link rel="stylesheet" type="text/css" href="footer.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
<?php
if(isset($_GET['success'])){?>


<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['regerror'])){?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
</script>
<?php }?>
    <section class="login register" id="register">
    <div class="loginbox">
        <h1 class="loginhead">Register</h1>
        <form method="post" action="">
            <label for="firstname">First Name </label><span class="error"><?= $nameErr?></span>
            <input type="text" name="firstname" class="field" placeholder="First Name">

            <label for="lastname">Last Name </label><span class="error"><?= $nameErr?></span>
            <input type="text" name="lastname" class="field" placeholder="Last Name">

            <label for="email">Email </label><span class="error"><?= $emailErr?></span>
            <input type="email" name="email" class="field" placeholder="Email address">

             <label for="company">Company Name </label><span class="error"><?= $companyErr?></span>
            <input type="text" name="company" class="field" placeholder="Company Name">

            <label for="role">Role </label><span class="error"><?= $roleErr?></span><br>
            <input type="text" name="role" class="field" placeholder="Your Company Role"> 

            <label for="password">Password </label><span class="error"><?= $pswErr?></span>
            <input type="password" name="password" class="field" placeholder="Password">

            <label for="reppassword"> Repeat Password </label><span class="error"><?= $repeat_err?></span>
            <input type="password" name="reppassword" class="field" placeholder="Repeat your password">

            <button type="submit" class="loginbtn" name="signup">Register</button> <br>
            <span class="noaccount">Already have an account?<br><a href="login.php" class="loginbox primarybtn.login">Log In</a></span>
        </form>
    </div>
</section> 
<?php 
include 'footer.php';
 ?>
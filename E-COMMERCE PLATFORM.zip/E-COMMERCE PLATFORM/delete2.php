 <?php 
session_start();
require 'connect.php';

 if (isset($_GET['order_id'])) {
        $_SESSION['order_id']=$_GET['order_id'];
        $sql = "DELETE orders FROM orders WHERE order_id = '$_GET[order_id]'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header("Location:mycart.php");
        }
        
     }

     if (isset($_GET['shop_id'])) {
        $_SESSION['shop_id']=$_GET['shop_id'];
        $sql = "DELETE shop FROM shop WHERE shop_id = '$_GET[shop_id]'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header("Location:makeshop.php");
        }
        
     }
      if (isset($_GET['product_id'])) {
        $_SESSION['product_id']=$_GET['product_id'];
        $sql = "DELETE products FROM products WHERE product_id = '$_GET[product_id]'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header("Location:shop.php");
        }
        
     }

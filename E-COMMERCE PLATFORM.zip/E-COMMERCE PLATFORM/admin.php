<?php 
session_start();
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==3) {
   header("Location:shop.php");
  die();
}
if ($_SESSION['role']==2) {
   header("Location:products.php");
  die();
}



 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Admin</title>
 	<link rel="stylesheet" type="text/css" href="style.css">
 	<link rel="stylesheet" type="text/css" href="footer.css">
 	<link rel="stylesheet" type="text/css" href="nav.css">
	<meta content="width=device-width,initial-scale=1" name="viewport">
 </head>
 <body>
 
  <div class="container">
  	<header>
           <?php include 'adminNav.php'; ?>
            <h1 class="controlhead" class="stat">
                Statistics
            </h1>
        </header>

 <!-- NUMs -->
 <section>
           

    <section class="box">
        <?php 
            $sql = " SELECT * FROM users  WHERE role = '1'";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
            Admins
         </h4>   
        </section>
        <section class="box">
        <?php 
            $sql = " SELECT * FROM users  WHERE role = '2'";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
             Customer
         </h4>   
        </section>
        <section class="box">
        <?php 
            $sql = " SELECT * FROM users  WHERE role = '3'";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
           Salers
         </h4>   
        </section>
        <section class="box">
        <?php 
            $sql = " SELECT * FROM Shop ";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
             Shops
         </h4>   
        </section>
        <section class="box">
        <?php 
            $sql = " SELECT * FROM Products";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
            Products
         </h4>   
        </section>
        <section class="box">
        <?php 
            $sql = " SELECT * FROM Orders WHERE success = '1'";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
           Completed Orders
         </h4>   
        </section>
        <section class="box">
        <?php 
            $sql = " SELECT * FROM Orders WHERE success = '0'";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
           Pending Orders
         </h4>   
        </section>


  </section>


        </div>
      

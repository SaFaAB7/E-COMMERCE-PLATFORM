<?php 
session_start();
require 'connect.php'; 
$mssg=''; 

  if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['send'])) {
    if (isset($_POST['mssg'])) {
    $mssg = $_POST['mssg'] ;  
    }
     $insert= "INSERT INTO messages (user_id , send_to_id ,message) VALUES ('$_SESSION[id]' ,$_SESSION[send_to_id], '$mssg')";
   $result1 = mysqli_query($conn, $insert);
   if ($result1) {
   	header("location:contact.php?user_id=$_SESSION[send_to_id]");
   }
  }
  ?>
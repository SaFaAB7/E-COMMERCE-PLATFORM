
   <nav>
        <a href="#" class="logo">MarKazy Shop</a>

        <ul>
            <li><a href="index.php">Home</a></li>
            
            <li><a href="about.php">About</a></li>
           <li><a href="mycart.php">Profile</a></li> 
            <li><a href="mycart.php">MyShop</a></li> 
            <li><a href="profile.php">Add Product</a></li>
            <li><a href="logout.php">Log Out</a></li>

        </ul>

        <button class="menu"><span><img src="image/menu.png"> <i class="fas fa-bars"></i></span></button>
    </nav>
    <script>
        let btn = document.querySelector("button");
        let ul = document.querySelector("ul");

        btn.onclick = function() {
            ul.classList.toggle("show");
        }
    </script>


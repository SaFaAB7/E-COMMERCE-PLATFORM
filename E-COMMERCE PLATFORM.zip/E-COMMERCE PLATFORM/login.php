<?php
session_start();
require 'connect.php';
// $sql ="SELECT * FROM users";
// $result=mysqli_query($conn,$sql);
// if (mysqli_num_rows($result) == 0){
//     header("Location:.php");
//     die();}
// elseif(isset($_SESSION['ID'])){
//     header("Location: index.php");
//     die();
// }

$email = $password = '';
$emailErr = $passwordErr = $Err ='';
if($_SERVER['REQUEST_METHOD'] == "POST"){
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
        unset($_POST['password']);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
        unset($_POST['password']);
    }
}else{
    $emailErr = "Email is required";
}if(isset($_POST['password'])){
    if(empty($_POST['password'])){
        $passwordErr = 'Password is required';
        unset($_POST['email']);
        unset($_POST['password']);
    }elseif($emailErr == ''){$sql = "SELECT * FROM users WHERE Email = '$_POST[email]' AND Password = '$_POST[password]'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if(mysqli_num_rows($result) == 0){
        $Err = "Incorrect Email or Password";
        unset($_POST['email']);
        unset($_POST['password']);
}else{
	$_SESSION['email']=$row['email'];
    $_SESSION['id']=$row['user_id'];
    $_SESSION['role']=$row['role'];
    if ($row['role']==3) {
    	header("Location: makeshop.php");
    }
    else {
    header("Location: index.php");}
}}}else{
    $passwordErr = "Password is required";
    unset($_POST['email']);
    unset($_POST['password']);}}?>

<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="register.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
     <section class="login register" id="register">
    <div class="loginbox">
        <h1 class="loginhead">Log In</h1>
<form method="post" action="">
<label for="email">Email </label><span class="error"><?= $emailErr?></span>
            <input type="email" name="email" class="field" placeholder="Email address">

              <label for="password">Password </label><span class="error"><?= $passwordErr?></span>
            <input type="password" name="password" class="field" placeholder="Password">

             <button type="submit" value="Log In" class="loginbtn" name="login">Log In</button><br>
            <span class="noaccount">Dont have an account?<br><a href="signas.php" class="primarybtn.login">Register Now</a></span>
        </form>
        </div>
        </section>



        <?php 
include 'footer.php';
 ?>

<?php 
session_start();
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
if(!isset($_GET['user_id'])){
    header("Location:index.php");
    die();
}

 ?>

<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Chat</title>
  <style media="screen">
  @import url('https://fonts.googleapis.com/css?family=Open+Sans');

*{
margin: 0;
padding: 0;
box-sizing: border-box;
outline: none;
text-decoration: none;
font-family: 'Open Sans', sans-serif;
}

.wrapper{
margin: 4% auto;
width: 85%;
height: auto;


padding: 20px 20px;
background-color: #F2F2F2;
}

.wrapper h2{
color: green;
text-align: center;
margin-bottom: 30px;
text-transform: uppercase;
letter-spacing: 3px;
}

h3 {
  color: grey;
  padding: 10px;
  padding-bottom: 5px;
  font-size: 15px;
}
p {
  border: 2px solid white;
  border-radius: 5%;
  width: 60%;
  background-color: white ;
  font-size: 17px;
  padding: 15px;
  font-weight: 600;


}

.sendto {
  float: left;
  clear:both;
}
.sendby {
  float: right;
  clear: both;
}
.wrapper .form textarea{
width: 100%;
padding: 14px;
border: none;
border-radius: 5px;
margin-bottom: 15px;
margin-top: 15px;
border: 1.5px solid rgba(255, 255, 255, 0.438);
border-radius: 3px;
background: rgba(105, 105, 105, 0.25);
clear: both;
font-size: 18px;
}

.wrapper .form textarea{
height: 90%;
resize: none;
}

button{
width: 200px;
background: green;
backdrop-filter: blur(10px);
margin: 0 auto;
padding: 13px;
font-size: 18px;
border-radius: 4px;
letter-spacing: 3px;
text-align: center;
color: white;
}

button a{
color: white;
}
span {
  text-align: center;
}

@media screen and (max-width: 1020px){

p{
  width: 75%;
}
@media screen and (max-width: 660px){

p{
  width: 80%;
}
@media screen and (max-width: 380px){

p{
  width: 85%;
}
.wrapper .form .form_right{
  width: 100%;
}
.wrapper .form textarea{
  height: 100px;
}
}

  </style>
</head>
<body>
  <div class="wrapper">
    <?php  
    $_SESSION['send_to_id']=$_GET['user_id'];

     $sql = "SELECT * FROM messages WHERE send_to_id ='$_GET[user_id]' ";
                $result = mysqli_query($conn ,$sql);
               
                
                
        $sql1 = "SELECT * FROM messages WHERE send_to_id ='$_SESSION[id]' ";
                $result1 = mysqli_query($conn ,$sql1);
                

                 $sql2 = "SELECT * FROM users WHERE user_id ='$_GET[user_id]' ";
                $result2 = mysqli_query($conn ,$sql2);
                $row2 = mysqli_fetch_assoc($result2)

                ?>
    <h2>Chat With <?=$row2['first_name']?></h2>

 <?php 
 if (mysqli_num_rows($result) > 0) {
  while ( $row1 = mysqli_fetch_assoc($result1)) {?>

     <h3 class="sendto"><?=$row2['first_name']?></h3>
    <p class="sendto"> <?=$row1['message']?></p>
  
  <?php } 
  while ( $row = mysqli_fetch_assoc($result)) { ?>
    <h3 class="sendby">You</h3>
    <p class="sendby"> <?=$row['message']?></p>
 <?php   } ?>
  
    <form class="form" action="chat.php" method="post">
      
      <div class="form_right">
        <textarea placeholder="Your Message*" name="mssg"></textarea>
      </div>
      
      <button class="btn" name="send" type="submit">
        Send 
      </button>

      <button class="btn"><a href="index.php">
       Back
     </a> </button>
    </form>
    </div>
              <?php } else {  ?>
                <span> No Messages Yet , Send Message</span>
                 <form class="form" action="chat.php" method="post">
      
      <div class="form_right">
        <textarea placeholder="Your Message*" name="mssg"></textarea>
      </div>
      
      <button class="btn" name="send">
        Send 
      </button>

      <button class="btn"><a href="index.php">
        back
     </a> </button>
    </form>
     <?php } ?>
</body>
</html>

<?php 
session_start();
require 'connect.php';


 	if ( !isset($_GET["product_id"]) ) {

 		die();
 		
}
elseif ( isset($_GET["product_id"]) )  {

       		  $insert = "INSERT INTO orders (user_id , product_id) VALUES ('$_SESSION[id]','$_GET[product_id]')";
    $result1 = mysqli_query($conn, $insert);
    if($result1){
    	header("Location:index.php");
    die(); 
}

else{
        echo "failed to insert";
    }
}

?>



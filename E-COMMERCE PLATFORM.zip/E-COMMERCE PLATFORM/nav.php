
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Side bar menu</title>
  <!-- Design by foolishdeveloper.com -->
  <style media="screen">
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
    
        font-family: sans-serif;
    }
    
    nav {
        position: fixed;
        top: 0;
        width: 100%;
        height: 70px;
        background-color: green;
    }
    
    .logo {
        font-family: sans-serif;
        font-weight: bolder;
    
        font-size: 26px;
        color: white;
        text-decoration: none;
        line-height: 70px;
        margin-left: 20px;
    }
    
    nav ul {
        float: right;
    }
    
    nav ul li {
        font-family: sans-serif;
        display: inline-block;
        font-size: 19px;
    
        line-height: 70px;
        padding: 0 15px;
    }
    
    nav ul li a {
        text-decoration: none;
        color: black;
    }
    nav ul  :hover{
      background-color: white;
    
    
    }
    
    button {
        position: absolute;
        top: 50%;
        right: 20px;
        outline: none;
        border: 1px solid #eae2e2;
        color: black;
        border: none;
        transform: translateY(-50%);
        background-color: transparent;
        width: 80px;
        height: 40px;
        font-size: 20px;
        font-weight: bolder;
        display: none;
    }
    
    @media (max-width:738px) {
    
        button {
            display: block;
        }
    
        nav ul {
            position: absolute;
            top: 70px;
            width: 100%;
            display: none;
            padding-top: 20px;
            padding-bottom: 20px;
            padding-left: 10px;
            background: grey;
            border-top: 1px solid #000;
        }
    
        nav ul li {
            display: block;
            text-align: center;
        }

    
        .show {
            display: block;
        }
    }

  </style>

</head>
<body>
   <nav>
        <a href="#" class="logo">MarKazy Shop</a>

        <ul>
            <li><a href="index.php">Home</a></li>
            
            <li><a href="about.php">About us</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="mycart.php">MyCart</a></li>
            <li><a href="logout.php">Log Out</a></li>

        </ul>

        <button><span><img src="image/menu.png"> <i class="fas fa-bars"></i></span></button>
    </nav>
    <script>
        let btn = document.querySelector("button");
        let ul = document.querySelector("ul");

        btn.onclick = function() {
            ul.classList.toggle("show");
        }
    </script>

</body>
</html>

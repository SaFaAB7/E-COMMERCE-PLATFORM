<?php 
session_start();
require 'connect.php';

if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==1) {
   header("Location:admin.php");
  die();
}
if ($_SESSION['role']==2) {
   header("Location:products.php");
  die();
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Shop</title>
	<link rel="stylesheet" type="text/css" href="footer.css">
	<link rel="stylesheet" type="text/css" href="nav.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
	<header>
		<?php 
include 'salNav.php';
		 ?>
	</header>

	<?php 
        $sql = "SELECT * FROM shop WHERE user_id = '$_SESSION[id]'";
            $result = mysqli_query($conn ,$sql);
          $row = mysqli_fetch_assoc($result);
          $sql1 = "SELECT * FROM users WHERE user_id = '$row[user_id]'";
           $result1 = mysqli_query($conn ,$sql1);
          $row1 = mysqli_fetch_assoc($result1);
	 
	 ?>
    <h1> Welcome <?=$row1['first_name']?></h1>
    <section>
    	<h2>
    		Your Shop Information
    	</h2>
    	<h3> Shop Name :</h3>
    	<h4><?=$row['shop_name']?></h4>
    	<h3>Shop Owner :</h3>
    	<h4><?=$row1['first_name']?> <?=$row1['last_name']?></h4>
    	<h3> About Your Shop :</h3>
    	<h4><?=$row['shop_description']?></h4>
    	<a href="delete2.php?shop_id=<?=$row['shop_id'] ?>">delete shop</a>
    </section>
    <section>
    	<h2>Your Products</h2>
    	
 

    		 <?php  
   $sql = "SELECT * FROM products WHERE shop_id = '$row[shop_id]' ";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) { 
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th></th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {
            	?>
                        
                        <tr>
                            <td><?=$row['product_id']?></td>
                             <td><?=$row['product_name']?></td>
                             <td> <?=$row['price']?></td>
                             <td></td>
                             <td></td> 
                                <form action="delete.php" method="get"><td><a href="delete2.php?product_id=<?=$row['product_id'] ?>">delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
    		       
    	</section>


<?php 
include 'footer.php';
 ?>
<?php 
session_start();
require 'connect.php';


  
  $shopName = $shopDesc = $shopNameErr = $shopDescErr = '';
  if($_SERVER['REQUEST_METHOD'] == "POST"){
  	if (isset($_POST['send'])) {
  	
    if(isset($_POST["name"])){
        $shopName=$_POST["name"];
        if(empty($_POST["name"])){
        $shopNameErr = "shop Name is required";
        unset($_POST["name"]);}
} 
if (isset($_POST["desc"])){
        $shopDesc=$_POST["desc"];
        if(empty($_POST["desc"])){
        $shopDescErr = "shop Description is required";
        unset($_POST["desc"]);}
}
     // if (!empty($_FILES['image'])) {
     //       $imageName = $_FILES['image']['name'];
     //    $tmp = $_FILES['image']['tmp_name'];

     //    $upload = 'images/'.$imageName;
     //    if ($_FILES['image']['error'] == 0) {
     //        if (move_uploaded_file($tmp, $upload)) { 
                if ($shopNameErr =='' and $shopDescErr == '') {
      $sql = "INSERT INTO shop (shop_name ,user_id , description) VALUES ('$shopName' , '$_SESSION[id]', '$shopDesc')";
        $result = mysqli_query($conn ,$sql); 
   if ($result) {
    header("location:shop.php");
   }
    
        elseif (!$result) {
         unset($_POST["send"]);
         unset($_POST["name"]);
          unset($_POST["desc"]);
  
  // }
 }
}
}
}
    
 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Shop</title>
  <link rel="stylesheet" type="text/css" href="footer.css">
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
 
      <section>

  <div class="container">
     
       <section id="addshop">
        <h2>Make Shop</h2>
        <form action="" method="post">
            <label for="name">Shop Name</label><br> <span class="error"><?= $shopNameErr ?></span>
            <input type="text" name="name" id="name" placeholder="Shop Name"><br>


              <label for="desc">About Yor Shop</label><br>  <span class="error"><?= $shopDescErr ?></span>
            <textarea type="text" name="desc" id="desc" placeholder="Shop Description"></textarea><br>


            <button type="submit" id="send" name="send">Add</button>
            
        </form>
  </section>
  
<?php 
include 'footer.php';
 ?>
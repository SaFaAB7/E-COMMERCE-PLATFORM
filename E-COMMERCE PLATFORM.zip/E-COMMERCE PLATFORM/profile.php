<?php 
session_start();
require 'connect.php';



 ?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=divice-width, initial-scale=1.0">
  <title>Profile</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
  <link rel="stylesheet" type="text/css" href="style.css">
  
 
  <style media="screen">
  	* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    /* background-color: #EA9684; */
    font-family: Arial, Helvetica, sans-serif;
    background-color: #e2dfdf;
   

}

main {
    width: 58%;
    overflow: hidden;
    background-color: #F2F2F2;
    font-size: 16px;
    line-height: 22px;
    color: grey;
    border-radius: 7px;
    margin: 50px auto;

}

.top-card {
    width: 70%;
    margin: 0 auto;
    /* height: 200px; */
}

.card-img {
  width: 70%;

  margin: 10px auto;
}
.card-img img {
    width: 100%;
    height: 290px;
    border-radius: 50%;
}



 

h1 {
    font-size: 19px;
    color: green;
    font-weight: 600;
    margin: 12px 0;
    text-align: left;
    border-bottom: 1px grey solid ;
    padding: 5px;
    margin: 10px;
    margin-top: 20px;

}
p{
  color: rgb(9 48 8);
}


.middle-card, footer {
    margin: 5px 25px;
}

.middle-card {
    text-align: justify;
}

footer {
    text-align: center;

}

footer .social-icon {
    /* padding: 7%; */
    font-size: 20px;
    margin: 0 5%;
    color: rgba(0, 0, 0, .9);
}

.facebook:hover {color:#3b5999;}
.twitter:hover {color: #55acee;}
.google:hover {color: #dd4b39;}
.github:hover {color: #302f2f;}
.linkedin:hover {color: #0077B5;}

footer .links {
    border-top: 2px solid rgba(0, 0, 0, .1);
    text-align: center;
    margin-top: 10px;
    padding: 8px 0;

}



button{
	width: 110px;
	height: 37px;
	margin-top: 10px;
	border-radius: 2px;
	background: green;
	font-size: 15px;
	border: none;
	color: white;
}
button:last-child{
	margin-left: 40px;
	border: 2px solid green;
	background: white;
	color: black;
}
@media (max-width: 890px ){

.card-img img {
    height: 260px;
    
}
}
@media (max-width: 710px) {
  main {
    width: 73%
  }
 .top-card {
    width: 80%;
    margin: 0 auto;
    /* height: 200px; */
}

.card-img {
  width: 80%;

  margin: 10px auto;
}
.card-img img {
    width: 100%;
    height: 280px;
    border-radius: 50%;
}
}
@media (max-width: 580px) {
  main {
    width: 76%
  }
   .top-card {
    width: 83%;
    margin: 0 auto;
    /* height: 200px; */
}

.card-img {
  width: 83%;

  margin: 10px auto;
}
.card-img img {
    width: 100%;
    height: 250px;
    border-radius: 50%;
}
}
@media (max-width: 470px) {
  main {
    width: 85%
  }
   
}
@media (max-width: 390px) {
  main {
    width: 92%
  }
  
.card-img img {
    height: 220px;
   
}
}

  </style>
</head>
<body>

  <main>
    <section>
    <section class="top-card">
      <div class="card-img">
      <img src="image/background1.jpg" alt="user picture">
     </div>

    </section>

    <section class="middle-card">

      <?php 
 $sql = "SELECT * FROM users WHERE user_id ='$_SESSION[id]' ";
                $result = mysqli_query($conn ,$sql);
                 if ( mysqli_num_rows($result) > 0) { 
                  $row = mysqli_fetch_assoc($result);
       ?>
      <h1><?=$row['first_name']?> <?=$row['last_name']?></h1>
      <?php 
          if ($row['role']==2) { ?>
            <h1><?=$row['company_name']?></h1>
      <h1><?=$row['company_role']?></h1>
      <?php } elseif ($row['role']==3) {
       ?> <h1>Shop</h1>
       <?php }  elseif ($row['role']==1) {?>
        <h1>Admin</h1> <?php } ?>
     
      <p>About :Lorem ipsum dolor sit amet consectetur, adipisicing elit. Atque iure earum, molestiae voluptatibus amet minus dolore.</p>
    </section>

    <footer>
      <h1></h1>

      <section class="links">
<button>Contact</button>
<button><a href="index.php">Back</a></button>
      </section>
    </footer>
  <?php } else{ }?>
   </section>
  </main>


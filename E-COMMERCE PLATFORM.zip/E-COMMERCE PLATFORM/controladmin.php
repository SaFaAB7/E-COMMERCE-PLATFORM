<?php 
session_start();
require 'connect.php';

if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==3) {
   header("Location:shop.php");
  die();
}
if ($_SESSION['role']==2) {
   header("Location:products.php");
  die();
}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
	<link rel="stylesheet" type="text/css" href="nav.css">
	<meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
	<section id="control">
		<header>
<?php include 'adminNav.php'; ?>

 
  <h1 class="controlhead">
		Control Tables
	</h1>
</header>
<section  class="control">

	<h2>
		Admins
	</h2>
<?php  
   $sql = "SELECT * FROM users WHERE role ='1' ";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) { 
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Block</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {?>
                        
                        <tr>
                            <td><?=$row['user_id']?></td>
                             <td><?=$row['first_name']?> <?=$row['last_name']?></td>
                             <?php  if ($row['block']== 1) { ?>
                             	 <form action="unblock.php" method="get"><td><a href="unblock.php?user_id=<?= $row['user_id'] ?>">UnBlock</a> </td></form>
                             <?php } else { ?>
                               <form action="block.php" method="get"><td><a href="block.php?user_id=<?= $row['user_id'] ?>">Block</a> </td></form>
                           <?php } ?>
                                <form action="delete.php" method="get"><td><a href="delete.php?user_id=<?=$row['user_id'] ?>">delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>
   
   <section class="control">
   	<h2>
		Customers
	</h2>
  <?php  
   $sql = "SELECT * FROM users WHERE role ='2' ";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) { 
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Company Name</th>
                        <th>Role</th>
                        <th>Block</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {?>
                        
                        <tr>
                            <td><?=$row['user_id']?></td>
                             <td><?=$row['first_name']?> <?=$row['last_name']?></td>
                             <td><?=$row['company_name']?></td>
                             <td><?=$row['company_role']?></td>
                             <?php  if ($row['block']== 1) { ?>
                             	 <form action="unblock.php" method="get"><td><a href="unblock.php?user_id=<?= $row['user_id'] ?>">UnBlock</a> </td></form>
                             <?php } else { ?>
                               <form action="block.php" method="get"><td><a href="block.php?user_id=<?= $row['user_id'] ?>">Block</a> </td></form>
                           <?php } ?>
                                <form action="delete.php" method="get"><td><a href="delete.php?user_id=<?=$row['user_id'] ?>">delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>

   <section class="control">
   	<h2>
		Salers
	</h2>
  <?php  
   $sql = "SELECT * FROM users WHERE role ='3' ";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) { 
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Shop Name</th>
                        <th>Block</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {
                         $sql1 = "SELECT * FROM shop WHERE user_id = '$row[user_id]' ";
                $result1 = mysqli_query($conn ,$sql1);

            if ( mysqli_num_rows($result1) > 0) { 
                    $row1 = mysqli_fetch_assoc($result1); }
            	?>
                        
                        <tr>
                            <td><?=$row['user_id']?></td>
                             <td><?=$row['first_name']?> <?=$row['last_name']?></td>
                             <td><?=$row1['shop_name']?></td>
                             <?php  if ($row['block']== 1) { ?>
                             	 <form action="unblock.php" method="get"><td><a href="unblock.php?user_id=<?= $row['user_id'] ?>">UnBlock</a> </td></form>
                             <?php } else { ?>
                               <form action="block.php" method="get"><td><a href="block.php?user_id=<?= $row['user_id'] ?>">Block</a> </td></form>
                           <?php } ?>
                                <form action="delete.php" method="get"><td><a href="delete.php?user_id=<?=$row['user_id'] ?>">delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>
  <section class="control">
   	<h2>
		Shops
	</h2>
  <?php  
   $sql = "SELECT * FROM shop ";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) { 
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Shop Name</th>
                        <th>Owner Name</th>
                        <th>Status</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {
                    	 $sql1 = "SELECT * FROM users WHERE user_id = '$row[user_id]' ";
                $result1 = mysqli_query($conn ,$sql1);

            if ( mysqli_num_rows($result) > 0) { 
                    $row1 = mysqli_fetch_assoc($result1); }
            	?>
                        
                        <tr>
                            <td><?=$row['shop_id']?></td>
                             <td><?=$row['shop_name']?></td>
                             <td><?=$row1['first_name']?> <?=$row1['last_name']?></td>
                             <td><?php if ($row1['block']==0) { ?>
                             	UnBlocked</td>
                            <?php } elseif ($row1['block']==1) { ?>
                            	Blocked
                             <?php } ?> 
                                <form action="delete.php" method="get"><td><a href="delete.php?user_id=<?=$row['user_id'] ?>">delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>

   <section class="control">
   	<h2>
		Products
	</h2>
  <?php  
   $sql = "SELECT * FROM products ";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) { 
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Shop Name</th>
                        <th>Price</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {
                    	 $sql1 = "SELECT * FROM shop WHERE shop_id = '$row[shop_id]' ";
                $result1 = mysqli_query($conn ,$sql1);

            if ( mysqli_num_rows($result) > 0) { 
                    $row1 = mysqli_fetch_assoc($result1); }
            	?>
                        
                        <tr>
                            <td><?=$row['product_id']?></td> 
                            <td><?=$row['product_name']?></td>
                             <td><?=$row1['shop_name']?></td>
                             <td><?=$row['price']?></td>
                             
                                <form action="delete.php" method="get"><td><a href="delete.php?user_id=<?=$row['user_id'] ?>">delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>


   <section class="control">
   	<h2>
		Orders
	</h2>
  <?php  
   $sql = "SELECT * FROM orders ";
                $result = mysqli_query($conn ,$sql);

            if ( mysqli_num_rows($result) > 0) {
            	?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Shop</th>
                        <th>Customer</th>
                        <th>Status</th>
                        <th>Delete</th>
   
                        
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {
                    	 $sql1 = "SELECT * FROM products WHERE product_id = '$row[product_id]' ";
                $result1 = mysqli_query($conn ,$sql1);
                 if ( mysqli_num_rows($result1) > 0) { 
                    $row1 = mysqli_fetch_assoc($result1); 
                     
                 $sql2 = "SELECT * FROM shop WHERE shop_id = '$row1[shop_id]' ";
                $result2 = mysqli_query($conn ,$sql2);
                                 if ( mysqli_num_rows($result2) > 0) { 
                $row2 = mysqli_fetch_assoc($result2); }

                }
                 $sql3 = "SELECT * FROM users WHERE user_id = '$row[user_id]' ";
                $result3 = mysqli_query($conn ,$sql3);
                                 if ( mysqli_num_rows($result3) > 0) { 
                 $row3= mysqli_fetch_assoc($result3); }

           
            	?>
                        
                        <tr>
                            <td><?=$row['order_id']?></td> 
                            <td><?=$row1['product_name']?></td>
                             <td><?=$row2['shop_name']?></td>
                             <td><?=$row3['first_name']?></td>
                             <td><?php  if ($row['success']==1) {?>
                             	Completed 
                             	<td>-</td><?php } elseif ($row['success']==0) { ?>
                             		Waiting 
                            </td>
                             
                                <form action="delete.php" method="get"><td><a href="delete.php?order_id=<?=$row['order_id'] ?>">delete</a> </td></form> <?php } ?> 
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>
</section>
 
<?php 
include 'footer.php';
 ?>